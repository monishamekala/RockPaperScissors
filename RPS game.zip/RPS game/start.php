<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	</head>
	<style>
		.al{
			text-align: center;
		}
	</style>
</html>
<body>
	<nav class="navbar navbar-light bg-light">
	  <div class="container-fluid">
	    <a class="navbar-brand" href="#">
	      <img src="./img/arrow.png" alt="" width="30" height="24" class="d-inline-block align-text-top">
	      After Playing 50 Rounds
	    </a>
	  </div>
	</nav>
	<br>
	<div class="container">
		<a href="./index.php" type="button" class="btn btn-outline-dark btn-lg">Back</a>
	</div>
	<br>
	<?php
		#Array of arrays where each array specifies each player and her score
		$result = array(array(),array(),array(),array());
		 for ($i=1; $i<=4; $i++){ 
		 	for ($j=1; $j <=4 ; $j++) { 
		 		$result[$i][$j] = 0; 
		 	}
		 }
		#choices
		$chance = array(0 => 'Rock', 1=>'Paper', 2 =>'Scissors' );
		#To generate the choices randomly for 50 times
		for ($x = 1; $x <= 50; $x++) {
			$p1 = array_rand($chance,1);
			$p2 = array_rand($chance,1);
			$p3 = array_rand($chance,1);
			$p4 = array_rand($chance,1);

			#Assigning each player with their  random choice
			$players_opt = array(1=>$chance[$p1], 2=>$chance[$p2], 3=>$chance[$p3], 4=>$chance[$p4]);
	?>
			<div class="container">
				<p class="p">
					<i>
						<b>
							<?php 
								if ($x < 15) {
									echo "Iteration: $x";
								}
								elseif ($x = 15) {
									echo "Goes on...";
								}
							?>
						</b>
					</i>
				</p>
				<!-- To display each player's choice -->
				<table class="table table-bordered table-hover">
					<thead>
						<tr>
							<th>Player 1</th>
							<th>Player 2</th>
							<th>Player 3</th>
							<th>Player 4</th>
						</tr>
					</thead>
					<tbody>
						<td><?php echo "$players_opt[1]" ?></td>
						<td><?php echo "$players_opt[2]" ?></td>
						<td><?php echo "$players_opt[3]" ?></td>
						<td><?php echo "$players_opt[4]" ?></td>
					</tbody>
				</table>
				<br>
			</div>
	<?php
	#To set each player's score in each round/iteration
			for ($i=1; $i <=4 ; $i++) { 
				for ($j=1; $j <=4 ; $j++) { 
					if ($i == $j){
						$result[$i][$j] = '-';
					} elseif ($players_opt[$i]=='Paper' and $players_opt[$j]=='Rock') {
						$result[$i][$j] = $result[$i][$j] + 1; #Adds up to the previous round's score
						#Paper beats Rock

					} elseif ($players_opt[$i]=='Rock' and $players_opt[$j]=='Scissors') {
						$result[$i][$j] = $result[$i][$j] + 1;
						#Rock beats Scissors

					} elseif ($players_opt[$i]=='Scissors' and $players_opt[$j]=='Paper') {
						$result[$i][$j] = $result[$i][$j] + 1;
						#Scissors beats Paper
					} else{
						$result[$i][$j] = $result[$i][$j] + 0;
					}
				}
			}
			?>
			<!--The score table-->
			<div class="container">
				<table class="table table-dark table-hover">
					<thead>
						<tr>
							<th>Totals</th>
							<th></th>
							<th></th>
							<th class="al">Against</th>
						</tr>
						<tr>
							<th></th>
							<th></th>
							<th>Player 1</th>
							<th>Player 2</th>
							<th>Player 3</th>
							<th>Player 4</th>
						</tr>
					</thead>
					<tbody>
						<?php
							for ($i=1; $i <=4 ; $i++) {  ?>
								<tr>
									<td><?php if ($i == 1){
										echo "Player wins";}
										?>
									</td>
									<td><?php echo "Player $i"?></td>
									<td><?php print $result[$i][1]?></td>
									<td><?php print $result[$i][2]?></td>
									<td><?php print $result[$i][3]?></td>
									<td><?php print $result[$i][4]?></td>
								</tr>
						<?php   
							}
						?>
					</tbody>
				</table>
			</div>
	<?php
	} 
	?>
</body>
