<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<style>  
		.container{  
		text-align: center;  
		width: 300px;  
		height: 200px;  
		padding-top: 100px;  
		}  
		#btn{  
		font-size: 25px;  
		}  
		.flow_margin{
			text-indent: 100px;
			margin-top: 20px;
		}
		.p{
			font-size: 20px;
		} 
		.blink_img {
  			animation: blinker 2s linear infinite;
		}
		@keyframes blinker {
		  50% { opacity: 0; }
		}
		@keyframes blin {
		  50% { opacity: 0; }
		}
	</style>
	<title>Rock Paper Scissors</title>
</head>
<!--rgb: red green blue gradients-->
<body style="background-color: #343a40;">
	<nav class="navbar navbar-light bg-light">
	  <div class="container-fluid">
	    <a class="navbar-brand" href="#">
	      <img src="./img/rps.png" alt="" width="35" height="30" class="d-inline-block align-text-top">
	      Play Rock Paper Scissors
	    </a>
	  </div>
	</nav>
	<br>
	<span class="blink_img"><img src="./img/bgrd.png" style="width:300px; margin-left: 100px" /></span>
	<font color="white">
		<div class="flow_margin">
			<h2>Game Flow</h2>
			<p class="p"><i>1. Paper beats Rock</i></p>
			<p class="p"><i>2. Rock beats Scissors</i></p>
			<p class="p"><i>3. Scissors beats Paper</i></p>
		</div>
	</font>
	<div class="container">
		<a href="./start.php" type="button" class="btn btn-outline-light btn-lg">OK! Lets Start</a>
	</div>
</body>
</html>